export type DestinationId = "kyoto" | "lisbon" | "reykjavik";
export type DayId = "Day 1" | "Day 2" | "Day 3";
export type Category = "All" | "Culture" | "Food" | "Outdoors" | "Slow travel";

export type Currency = {
  code: string;
  symbol: string;
};

export type CurrencyCode = "JPY" | "EUR" | "ISK";

export type PlannedActivity = {
  activityId: string;
  quantity: number;
};

export type Activity = {
  id: string;
  name: string;
  category: Exclude<Category, "All">;
  description: string;
  details: string;
  duration: string;
  price: number;
  location: string;
  image: string;
  accent: string;
};

export type Destination = {
  id: DestinationId;
  name: string;
  country: string;
  days: string;
  image: string;
  note: string;
  currency: Currency;
};

export const destinations: Destination[] = [
  {
    id: "kyoto",
    name: "Kyoto",
    country: "Japan",
    days: "3 days",
    image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=86",
    note: "Temple paths, quiet lanes, and small rituals.",
    currency: { code: "JPY", symbol: "¥" },
  },
  {
    id: "lisbon",
    name: "Lisbon",
    country: "Portugal",
    days: "3 days",
    image: "https://images.unsplash.com/photo-1509840841025-9088ba78a826?auto=format&fit=crop&w=1200&q=86",
    note: "Sun-warmed tiles, sea air, and late dinners.",
    currency: { code: "EUR", symbol: "€" },
  },
  {
    id: "reykjavik",
    name: "Reykjavík",
    country: "Iceland",
    days: "3 days",
    image: "https://images.unsplash.com/photo-1504893524553-b855bce32c67?auto=format&fit=crop&w=1200&q=86",
    note: "Wide skies, warm pools, and wild edges.",
    currency: { code: "ISK", symbol: "kr" },
  },
];

export const activityData: Record<DestinationId, Activity[]> = {
  kyoto: [
    {
      id: "kyoto-tea",
      name: "Tea ceremony in Gion",
      category: "Culture",
      description: "A quiet introduction to matcha, movement, and Kyoto ritual.",
      details:
        "Step into a small machiya house tucked behind Gion's lantern-lit lanes. A host guides you through the rhythms of whisking matcha, seasonal sweets, and the ideas behind ichi-go ichi-e — one time, one meeting.",
      duration: "1 hr 30 min",
      price: 42,
      location: "Gion, Kyoto",
      image: "https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=900&q=86",
      accent: "#d85d43",
    },
    {
      id: "kyoto-fushimi",
      name: "Fushimi Inari at first light",
      category: "Outdoors",
      description: "Walk the vermilion gates before the city wakes up.",
      details:
        "Meet your local guide near the lower shrine and follow the forested trail as the light changes. This gentle early walk gives you context on the shrine's history, fox symbolism, and the best quiet overlooks.",
      duration: "2 hr 15 min",
      price: 28,
      location: "Fushimi, Kyoto",
      image: "https://images.unsplash.com/photo-1478436127897-769e1b3f0f36?auto=format&fit=crop&w=900&q=86",
      accent: "#a14d35",
    },
    {
      id: "kyoto-nishiki",
      name: "Nishiki market tasting walk",
      category: "Food",
      description: "Five neighborhood bites with a chef who knows every stall.",
      details:
        "Taste your way through Kyoto's covered kitchen with a chef-host. Expect dashi-rich broth, pickles, yuba, seasonal wagashi, and a few stories about the vendors who have shaped the market.",
      duration: "2 hr",
      price: 64,
      location: "Nishiki, Kyoto",
      image: "https://images.unsplash.com/photo-1554797589-7241bb691973?auto=format&fit=crop&w=900&q=86",
      accent: "#c89438",
    },
    {
      id: "kyoto-philosopher",
      name: "Philosopher's Path by bicycle",
      category: "Slow travel",
      description: "A leafy ride between small temples and neighborhood coffee.",
      details:
        "Take the long way between Ginkaku-ji and Nanzen-ji on a lightweight city bicycle. Your route follows the canal, pauses at a hand-drip coffee shop, and leaves room for whatever catches your eye.",
      duration: "3 hr",
      price: 35,
      location: "Higashiyama, Kyoto",
      image: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=900&q=86",
      accent: "#5c786c",
    },
    {
      id: "kyoto-ryokan",
      name: "Evening at a neighborhood sento",
      category: "Slow travel",
      description: "Warm up, slow down, and borrow a local evening ritual.",
      details:
        "A small-group introduction to sento etiquette followed by time to soak at a neighborhood bathhouse. Towels, a locker, and a little printed guide are included so you can settle in with confidence.",
      duration: "1 hr 45 min",
      price: 18,
      location: "Nishijin, Kyoto",
      image: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?auto=format&fit=crop&w=900&q=86",
      accent: "#819a8e",
    },
  ],
  lisbon: [
    {
      id: "lisbon-alfama",
      name: "Alfama stories & pastries",
      category: "Culture",
      description: "Follow the oldest streets with a resident storyteller.",
      details:
        "Climb the tiled lanes of Alfama with a local writer who will point out hidden courtyards, old fado houses, and the tiny bakeries worth stopping for. Come hungry and wear comfortable shoes.",
      duration: "2 hr",
      price: 38,
      location: "Alfama, Lisbon",
      image: "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?auto=format&fit=crop&w=900&q=86",
      accent: "#d85d43",
    },
    {
      id: "lisbon-tram",
      name: "Tram 28, the long way",
      category: "Slow travel",
      description: "Ride the famous line with a pause for a neighborhood lunch.",
      details:
        "Skip the rush and trace the historic route in two relaxed legs, with time to step off for a bifana and a view. Your guide shares the history of the line and the streets it still connects.",
      duration: "3 hr",
      price: 24,
      location: "Graça, Lisbon",
      image: "https://images.unsplash.com/photo-1513735492246-483525079686?auto=format&fit=crop&w=900&q=86",
      accent: "#d0a449",
    },
    {
      id: "lisbon-surf",
      name: "Atlantic beginner surf",
      category: "Outdoors",
      description: "A small group lesson on a bright, uncrowded stretch of coast.",
      details:
        "Head west with a patient instructor for a two-hour introduction to the Atlantic. Wetsuit, board, transfer, and a warm drink after the lesson are included.",
      duration: "4 hr",
      price: 72,
      location: "Carcavelos, Lisbon",
      image: "https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=900&q=86",
      accent: "#4e7c83",
    },
    {
      id: "lisbon-tasca",
      name: "Tasca table for two",
      category: "Food",
      description: "A generous local dinner in three tiny neighborhood stops.",
      details:
        "Share petiscos, regional wine, and a little dessert across three family-run spots away from the main squares. The menu follows what looks best that day.",
      duration: "2 hr 30 min",
      price: 68,
      location: "Mouraria, Lisbon",
      image: "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=86",
      accent: "#9b5c39",
    },
    {
      id: "lisbon-tile",
      name: "Make your own azulejo",
      category: "Culture",
      description: "Design a tile with a working artist in a bright old studio.",
      details:
        "Learn the basics of Portuguese tile painting, from pattern to pigment, then make a piece to take home. No experience needed; just bring an idea or borrow one from the studio wall.",
      duration: "2 hr",
      price: 46,
      location: "Estrela, Lisbon",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&w=900&q=86",
      accent: "#40708b",
    },
  ],
  reykjavik: [
    {
      id: "reykjavik-lagoon",
      name: "Sky Lagoon at golden hour",
      category: "Slow travel",
      description: "A long soak, ocean views, and the seven-step ritual.",
      details:
        "Ease into the geothermal water at the edge of the Atlantic, then follow the warm-cold ritual at your own pace. A towel, ritual pass, and a quiet seat with a view are included.",
      duration: "2 hr 30 min",
      price: 86,
      location: "Kópavogur",
      image: "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=900&q=86",
      accent: "#4c7983",
    },
    {
      id: "reykjavik-food",
      name: "Harbor-to-table supper",
      category: "Food",
      description: "A five-course tasting menu rooted in the North Atlantic.",
      details:
        "Taste Iceland through a thoughtful five-course menu built around the day's catch, rye, wild herbs, and local dairy. Your host explains the landscapes behind every plate.",
      duration: "2 hr 45 min",
      price: 94,
      location: "Old Harbour, Reykjavík",
      image: "https://images.unsplash.com/photo-1515003197210-e0cd71810b5f?auto=format&fit=crop&w=900&q=86",
      accent: "#bd7b4a",
    },
    {
      id: "reykjavik-coast",
      name: "The coast by e-bike",
      category: "Outdoors",
      description: "A wind-friendly ride along the city's wide-open edge.",
      details:
        "Cruise the shoreline on an electric bike with stops at a lighthouse, a sculpture garden, and a local bakery. The route is easygoing and designed for changing weather.",
      duration: "3 hr 30 min",
      price: 58,
      location: "Seltjarnarnes",
      image: "https://images.unsplash.com/photo-1476610182048-b716b8518aae?auto=format&fit=crop&w=900&q=86",
      accent: "#6f8d8c",
    },
    {
      id: "reykjavik-northern",
      name: "Northern lights, without the bus",
      category: "Outdoors",
      description: "A small-group chase with a photographer and hot chocolate.",
      details:
        "Leave the city in a comfortable 4x4 with a local photographer who reads the cloud cover and the forecast. You will get help with settings, but the night is yours to experience.",
      duration: "4 hr",
      price: 79,
      location: "Outside Reykjavík",
      image: "https://images.unsplash.com/photo-1483347756197-71ef80e95f73?auto=format&fit=crop&w=900&q=86",
      accent: "#52628b",
    },
    {
      id: "reykjavik-design",
      name: "Nordic design walk",
      category: "Culture",
      description: "Independent studios, wool, ceramics, and one excellent bookshop.",
      details:
        "Meet a design writer for a walk through the city's independent scene. Browse small studios, hear how Icelandic materials shape everyday objects, and leave with a short list for later.",
      duration: "2 hr",
      price: 32,
      location: "Miðborg, Reykjavík",
      image: "https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&w=900&q=86",
      accent: "#ba8e54",
    },
  ],
};

export interface ValidatedItineraryItem {
  activity: Activity;
  quantity: number;
  itemSubtotal: number;
}

export interface ItineraryPriceCalculation {
  destination: Destination;
  totalCost: number;
  items: ValidatedItineraryItem[];
}

/**
 * Server-side calculation and verification of itinerary cost.
 * Strictly verifies each activity ID and recalculates subtotal and total
 * from authoritative server activity data. Never relies on client-provided amounts.
 */
export function calculateItineraryTotal(
  destinationId: DestinationId,
  items: PlannedActivity[]
): ItineraryPriceCalculation | null {
  const destination = destinations.find((d) => d.id === destinationId);
  if (!destination) return null;

  const activities = activityData[destinationId] || [];
  let totalCost = 0;
  const validatedItems: ValidatedItineraryItem[] = [];

  for (const item of items) {
    if (!item || typeof item.activityId !== "string") continue;
    const activity = activities.find((act) => act.id === item.activityId);
    if (!activity) continue;

    // Quantity must be a positive integer, minimum 1, max sanity cap of 50
    const rawQty = Number(item.quantity);
    const quantity = Number.isInteger(rawQty) && rawQty > 0 ? Math.min(rawQty, 50) : 1;
    const itemSubtotal = activity.price * quantity;

    totalCost += itemSubtotal;
    validatedItems.push({
      activity,
      quantity,
      itemSubtotal,
    });
  }

  return {
    destination,
    totalCost,
    items: validatedItems,
  };
}
