import type { Request, Response } from "express";
import Stripe from "stripe";
import {
  calculateItineraryTotal,
  destinations,
  type DestinationId,
  type PlannedActivity,
} from "../shared/activities.js";

// Stripe zero-decimal currencies: JPY, ISK, etc.
const ZERO_DECIMAL_CURRENCIES = new Set([
  "bif",
  "clp",
  "djf",
  "gnf",
  "jpy",
  "kmf",
  "krw",
  "mga",
  "pyg",
  "rwf",
  "ugx",
  "vnd",
  "vuv",
  "xaf",
  "xof",
  "xpf",
  "isk",
]);

/**
 * Converts a human-readable total amount to Stripe's smallest currency unit.
 * E.g., EUR 42 -> 4200 (cents), JPY 42 -> 42, ISK 86 -> 86.
 */
export function toStripeAmount(amount: number, currencyCode: string): number {
  const normalized = currencyCode.toLowerCase().trim();
  if (ZERO_DECIMAL_CURRENCIES.has(normalized)) {
    return Math.round(amount);
  }
  return Math.round(amount * 100);
}

/**
 * Retrieves the initialized Stripe client or returns null if STRIPE_SECRET_KEY is absent.
 */
export function getStripeClient(): Stripe | null {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey) {
    return null;
  }
  return new Stripe(secretKey);
}

export interface CreateIntentRequest {
  destinationId: DestinationId;
  itinerary?: Record<string, PlannedActivity[]>;
  items?: PlannedActivity[];
  currency?: string;
  customerEmail?: string;
  customerName?: string;
  metadata?: Record<string, string>;
}

/**
 * Handler for POST /api/payment/create-intent
 * Recalculates and verifies the total strictly on the server from authoritative
 * activity catalog data. Completely ignores any client-supplied total.
 */
export async function createPaymentIntentHandler(req: Request, res: Response) {
  try {
    const { destinationId, itinerary, items, customerEmail, customerName, metadata } =
      req.body as CreateIntentRequest;

    if (!destinationId) {
      return res.status(400).json({
        error: "Missing required 'destinationId'. Must be 'kyoto', 'lisbon', or 'reykjavik'.",
      });
    }

    const destination = destinations.find((d) => d.id === destinationId);
    if (!destination) {
      return res.status(400).json({
        error: `Unknown destination '${destinationId}'. Valid destinations: kyoto, lisbon, reykjavik.`,
      });
    }

    // Collect all planned activities from either flat items or grouped itinerary days
    let rawItems: PlannedActivity[] = [];
    if (Array.isArray(items)) {
      rawItems = items;
    } else if (itinerary && typeof itinerary === "object") {
      rawItems = Object.values(itinerary).flat();
    }

    if (!rawItems.length) {
      return res.status(400).json({
        error: "Itinerary is empty. Please select at least one activity before checkout.",
      });
    }

    // Recalculate amount strictly server-side from authoritative activity catalog
    const calculation = calculateItineraryTotal(destinationId, rawItems);
    if (!calculation || calculation.items.length === 0 || calculation.totalCost <= 0) {
      return res.status(400).json({
        error: "No valid payable activities found in the submitted itinerary.",
      });
    }

    const { totalCost, items: validatedItems } = calculation;
    const currencyCode = destination.currency.code.toLowerCase();
    const stripeAmount = toStripeAmount(totalCost, currencyCode);

    const stripe = getStripeClient();
    if (!stripe) {
      return res.status(500).json({
        error: "STRIPE_SECRET_KEY is not configured on the server.",
      });
    }

    // Create Stripe PaymentIntent in test mode
    const paymentIntent = await stripe.paymentIntents.create({
      amount: stripeAmount,
      currency: currencyCode,
      automatic_payment_methods: {
        enabled: true,
      },
      receipt_email: customerEmail || undefined,
      description: `ROAM slow travel: ${destination.name} (${validatedItems.length} activities)`,
      metadata: {
        destinationId,
        destinationName: destination.name,
        currencyCode: destination.currency.code,
        itemCount: String(validatedItems.length),
        totalCalculatedCost: String(totalCost),
        activitiesSummary: validatedItems
          .slice(0, 8)
          .map((i) => `${i.activity.id}:${i.quantity}`)
          .join(", "),
        ...(customerName ? { customerName } : {}),
        ...metadata,
      },
    });

    return res.status(200).json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
      amount: paymentIntent.amount,
      currency: paymentIntent.currency,
      totalCost,
      destinationId,
      itemCount: validatedItems.length,
    });
  } catch (err: any) {
    console.error("[Stripe] createPaymentIntentHandler error:", err);
    return res.status(500).json({
      error: err?.message || "Failed to create Stripe payment intent.",
    });
  }
}

/**
 * Handler for POST /api/payment/webhook
 * Uses raw body buffer to verify Stripe webhook signature and handles
 * payment_intent.succeeded and payment_intent.payment_failed events.
 */
export async function stripeWebhookHandler(req: Request, res: Response) {
  const sig = req.headers["stripe-signature"] as string | undefined;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  const stripe = getStripeClient();

  let event: Stripe.Event;

  if (webhookSecret && sig) {
    if (!stripe) {
      return res.status(500).send("Stripe client not initialized.");
    }
    try {
      event = stripe.webhooks.constructEvent(
        req.body as Buffer,
        sig,
        webhookSecret
      );
    } catch (err: any) {
      console.error("[Stripe Webhook] Signature verification failed:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }
  } else {
    // If webhook secret is not configured (e.g. testing), parse payload safely
    try {
      const rawPayload = Buffer.isBuffer(req.body)
        ? req.body.toString("utf8")
        : typeof req.body === "string"
        ? req.body
        : JSON.stringify(req.body);
      event = JSON.parse(rawPayload);
    } catch (err: any) {
      console.error("[Stripe Webhook] Payload parse error:", err.message);
      return res.status(400).send(`Payload Error: ${err.message}`);
    }
  }

  // Handle successful and failed PaymentIntent events
  switch (event.type) {
    case "payment_intent.succeeded": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      console.log(`[Stripe Webhook] PaymentIntent succeeded: ${paymentIntent.id}`);
      console.log(
        `  Amount: ${paymentIntent.amount} ${paymentIntent.currency} | Destination: ${paymentIntent.metadata?.destinationId}`
      );
      break;
    }

    case "payment_intent.payment_failed": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const errorMsg =
        paymentIntent.last_payment_error?.message || "Payment intent failed without message";
      console.warn(`[Stripe Webhook] PaymentIntent failed: ${paymentIntent.id}`);
      console.warn(`  Failure reason: ${errorMsg}`);
      break;
    }

    case "payment_intent.canceled": {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      console.log(`[Stripe Webhook] PaymentIntent canceled: ${paymentIntent.id}`);
      break;
    }

    default:
      console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
  }

  return res.status(200).json({ received: true });
}
