import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import {
  createPaymentIntentHandler,
  stripeWebhookHandler,
} from "./payment.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Stripe Webhook endpoint with raw-body parsing for signature verification
  app.post(
    "/api/payment/webhook",
    express.raw({ type: "application/json" }),
    stripeWebhookHandler
  );

  // JSON body parser for other API routes
  app.use(express.json());

  // Stripe PaymentIntent creation with authoritative server-side price recalculation
  app.post("/api/payment/create-intent", createPaymentIntentHandler);

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all non-API routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = Number(process.env.PORT) || 3000;

  server.listen(port, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${port}/`);
  });
}

startServer().catch(console.error);
